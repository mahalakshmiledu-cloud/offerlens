require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.jsdelivr.net', 'https://cdnjs.cloudflare.com'],
      workerSrc: ["'self'", 'blob:', 'https://cdn.jsdelivr.net', 'https://cdnjs.cloudflare.com'],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ['https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'", 'https://cdn.jsdelivr.net', 'https://cdnjs.cloudflare.com', 'https://tessdata.projectnaptha.com']
    }
  }
}));
app.use(express.json({ limit: '200kb' })); // text only, no file uploads reach the server
app.use('/api/', rateLimit({ windowMs: 60_000, max: 30 }));
app.use(express.static(path.join(__dirname, 'public')));

const FREE_MAIL = ['gmail.com','yahoo.com','outlook.com','hotmail.com','proton.me','protonmail.com','icloud.com','aol.com','rediffmail.com'];
const EMAIL_RE = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const domainOf = e => (String(e).split('@')[1] || '').toLowerCase().trim();
const hostOf = u => { try { return new URL(/^https?:/i.test(u) ? u : 'https://' + u).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; } };
const rootOf = h => h.split('.').slice(-2).join('.');
const clean = (s, n = 200) => String(s || '').slice(0, n).trim();

const RULES = [
  { id: 'fee', w: 30, title: 'Asks for a fee or deposit', why: 'Real employers do not charge candidates to start work.', re: /(registration|security|training|processing|refundable|joining|kit|laptop|document)\s+(fee|deposit|charge|amount)|pay\s+(a\s+)?(fee|deposit)|(deposit|transfer|pay)\s+(rs\.?|inr|\$|₹|usd)\s*\d+/i },
  { id: 'secrets', w: 30, title: 'Asks for passwords, OTP or bank details', why: 'No offer needs your password, one-time code, card or net-banking details.', re: /(password|otp|one[- ]time (code|password)|cvv|pin number|net ?banking|bank (account|details|login)|card number)/i },
  { id: 'payment', w: 20, title: 'Unusual payment instructions', why: 'Gift cards, crypto, UPI or wire transfers to individuals are common in scams.', re: /(gift ?card|bitcoin|crypto|western union|moneygram|upi id|wire transfer|send (the )?(money|payment))/i },
  { id: 'nointerview', w: 18, title: 'Interview skipped or minimal', why: 'Offers without any interview are a frequent scam pattern.', re: /(without (an )?interview|no interview|selected (directly|without)|direct (selection|joining)|chat interview|telegram interview)/i },
  { id: 'urgency', w: 12, title: 'Pressure to reply fast', why: 'Scammers rush you so you skip checks.', re: /(within \d+\s*(hours?|hrs?|minutes?)|immediately|urgent|last chance|limited (slots|seats)|expires (today|soon)|accept (today|now))/i },
  { id: 'channel', w: 10, title: 'Asks to move to WhatsApp/Telegram', why: 'Official hiring usually uses company email and systems.', re: /(whatsapp|telegram|signal app|text us on)/i }
];

function extract(text) {
  const emails = [...new Set((text.match(EMAIL_RE) || []).map(e => e.toLowerCase()))];
  const pick = re => { const m = text.match(re); return m ? clean(m[1], 80) : null; };
  const salaryM = text.match(/(?:₹|rs\.?|inr|\$|usd|eur|£)\s?[\d,]+(?:\.\d+)?(?:\s?(?:k|lpa|lakhs?|per\s+\w+|\/\s?\w+))?/i);
  return {
    candidateName: pick(/dear\s+(?:mr\.?|ms\.?|mrs\.?)?\s*([A-Z][A-Za-z.' -]{1,40})[,:\n]/),
    companyName: pick(/(?:company|organisation|organization)\s*(?:name)?\s*[:\-]\s*([^\n,]{2,60})/i) || pick(/(?:join|welcome to|offer from|at)\s+([A-Z][A-Za-z0-9&.' -]{2,40}?)(?:\s+(?:as|for|on|,|\.|\n))/),
    jobTitle: pick(/(?:position|role|job title|designation)\s*[:\-]\s*([^\n,]{2,60})/i) || pick(/(?:as an?|position of)\s+([A-Z][A-Za-z /&-]{2,40}?)(?:\s+(?:at|with|in|,|\.|\n))/),
    salary: salaryM ? salaryM[0] : null,
    emails,
    recruiterName: pick(/(?:regards|sincerely|recruiter|hr manager|talent acquisition)[,:\s]*\n?\s*([A-Z][a-z]+(?: [A-Z][a-z]+){0,2})/)
  };
}

app.post('/api/analyze', (req, res) => {
  const text = clean(req.body && req.body.text, 60000);
  if (text.length < 40) return res.status(400).json({ error: 'Add at least a few sentences of the offer text.' });
  const you = { name: clean(req.body.userName, 80), email: clean(req.body.userEmail, 120).toLowerCase() };
  const found = extract(text);
  const flags = []; let score = 100;

  for (const r of RULES) {
    const m = text.match(r.re);
    if (m) { flags.push({ id: r.id, kind: 'risk', title: r.title, why: r.why, snippet: clean(m[0], 80), impact: -r.w }); score -= r.w; }
  }
  const personal = found.emails.filter(e => FREE_MAIL.includes(domainOf(e)));
  if (personal.length) { flags.push({ id: 'freemail', kind: 'risk', title: 'Personal email provider used', why: 'Company recruiters normally write from a company domain. Some small firms do use personal mail, so check further.', snippet: personal[0].replace(/^[^@]+/, '•••'), impact: -10 }); score -= 10; }

  const pay = found.salary && text.match(/(\d[\d,]*)\s*(?:per|\/)\s*(day|week|hour)/i);
  if (pay || /(earn|salary|stipend)[^.]{0,40}(₹|rs\.?|\$)\s?[\d,]{6,}\s*(per|\/)\s*(week|day)/i.test(text)) { flags.push({ id: 'pay', kind: 'risk', title: 'Pay looks high for the period quoted', why: 'Very high daily or weekly pay for entry roles is a common lure.', snippet: found.salary, impact: -12 }); score -= 12; }

  const matches = [];
  const cmp = (label, given, hit) => matches.push({ label, status: !given ? 'unknown' : hit === null ? 'notfound' : hit ? 'match' : 'mismatch' });
  if (you.name) { const first = you.name.toLowerCase().split(/\s+/)[0]; cmp('Your name', you.name, found.candidateName ? found.candidateName.toLowerCase().includes(first) : (text.toLowerCase().includes(first) ? true : null)); }
  if (you.email) cmp('Your email', you.email, found.emails.length ? found.emails.includes(you.email) : null);
  matches.forEach(m => { if (m.status === 'mismatch') { score -= 8; flags.push({ id: 'mm-' + m.label, kind: 'mismatch', title: m.label + ' does not match', why: 'Offers are normally addressed to the right person. A mismatch can mean a mass-sent template.', impact: -8 }); } });

  const missing = ['candidateName', 'companyName', 'jobTitle', 'salary', 'recruiterName'].filter(k => !found[k]);
  score = Math.max(0, Math.min(100, score));
  const label = score >= 80 ? 'Fewer warning signs' : score >= 55 ? 'Some warning signs' : 'Several warning signs';
  res.json({ score, label, found, matches, flags, missing, checkedAt: new Date().toISOString(),
    explanation: flags.length ? `We spotted ${flags.length} item(s) worth a second look. This is a screening estimate based only on the text you gave us.` : 'No common warning phrases were found in this text. That does not prove the offer is genuine, so verify the employer too.' });
});

const PROV = process.env.TAVILY_API_KEY ? 'Tavily Search API' : 'Brave Search API';
async function search(q) {
  const tav = process.env.TAVILY_API_KEY, brv = process.env.BRAVE_API_KEY;
  if (!tav && !brv) return { ok: false, reason: 'No search API key is set on the server.' };
  try {
    let r;
    if (tav) r = await fetch('https://api.tavily.com/search', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tav }, body: JSON.stringify({ query: q, search_depth: 'advanced', max_results: 8 }), signal: AbortSignal.timeout(20000) });
    else r = await fetch('https://api.search.brave.com/res/v1/web/search?count=8&q=' + encodeURIComponent(q), { headers: { Accept: 'application/json', 'X-Subscription-Token': brv }, signal: AbortSignal.timeout(10000) });
    if (!r.ok) return { ok: false, reason: `Search service replied with status ${r.status}.` };
    const j = await r.json();
    const list = tav ? (j.results || []).map(x => ({ title: x.title, url: x.url, desc: x.content })) : ((j.web && j.web.results) || []).map(x => ({ title: x.title, url: x.url, desc: x.description }));
    return { ok: true, results: list.map(x => ({ title: clean(x.title, 120), url: x.url, desc: clean(x.desc, 220) })) };
  } catch { return { ok: false, reason: 'Search service could not be reached.' }; }
}

app.post('/api/verify', async (req, res) => {
  const b = req.body || {};
  const company = clean(b.company, 100), site = hostOf(clean(b.website, 200)), email = clean(b.recruiterEmail, 120).toLowerCase(), li = clean(b.linkedin, 300);
  if (!company) return res.status(400).json({ error: 'Enter the company name.' });
  const today = new Date().toISOString().slice(0, 10);
  const facts = [], warns = [], unknown = []; let score = 50;

  const eDom = domainOf(email);
  if (site && eDom) {
    const same = rootOf(eDom) === rootOf(site);
    (same ? facts : warns).push({ title: same ? 'Recruiter email domain matches the website you entered' : 'Recruiter email domain differs from the website', why: same ? 'A matching domain is one indicator only. Lookalike domains and spoofed senders exist.' : 'Impersonators often use a different or look-alike domain.', source: 'Your inputs', date: today });
    score += same ? 12 : -22;
  } else unknown.push({ title: 'Email and website domain not compared', why: 'Enter both a website and a recruiter email to compare them.' });
  if (eDom && FREE_MAIL.includes(eDom)) { warns.push({ title: 'Recruiter uses a personal email provider', why: 'Most companies use their own domain for hiring.', source: 'Your inputs', date: today }); score -= 10; }
  if (eDom && site && rootOf(eDom) !== rootOf(site) && rootOf(eDom).replace(/[-0-9]/g, '').includes(rootOf(site).split('.')[0].slice(0, 5))) { warns.push({ title: 'Email domain looks similar to the website but is not the same', why: 'Possible look-alike domain.', source: 'Your inputs', date: today }); score -= 12; }

  if (li) {
    const lh = hostOf(li);
    if (/(^|\.)linkedin\.com$/.test(lh)) unknown.push({ title: 'LinkedIn link has a valid format', why: 'We do not open or scrape LinkedIn. Open it yourself and check the company page, follower history and who posted the job.' });
    else { warns.push({ title: 'The LinkedIn link is not on linkedin.com', why: 'Links that imitate LinkedIn are used in phishing.', source: 'Your inputs', date: today }); score -= 15; }
  } else unknown.push({ title: 'No LinkedIn link provided', why: 'Optional, but a job post URL helps you compare details.' });

  const [a, c] = await Promise.all([search(`"${company}" official website`), search(`"${company}" scam OR fraud OR fake offer`)]);
  const sources = [];
  if (!a.ok) unknown.push({ title: 'Web search was unavailable', why: a.reason + ' No search-based checks were made.' });
  else {
    const hits = a.results.filter(r => hostOf(r.url) && (site ? rootOf(hostOf(r.url)) === rootOf(site) : false));
    if (site && hits.length) { facts.push({ title: 'Your website appears in search results for this company', why: 'This shows the site is indexed. It is not proof the company or this offer is genuine.', source: PROV, url: hits[0].url, date: today }); score += 8; }
    else if (site) { warns.push({ title: 'Website did not appear for this company name', why: 'It may be new, small, or unrelated. More evidence needed.', source: PROV, date: today }); score -= 8; }
    else unknown.push({ title: 'No website entered to compare with results', why: 'Enter the official website you found yourself.' });
    a.results.slice(0, 5).forEach(r => sources.push({ ...r, source: PROV, date: today }));
  }
  if (c.ok) {
    const bad = c.results.filter(r => /scam|fraud|fake|complaint|warning/i.test(r.title + ' ' + r.desc));
    if (bad.length) { warns.push({ title: `${bad.length} result(s) mention scam or fraud words`, why: 'These may be about a different company or an impersonation. Read them before deciding.', source: PROV, url: bad[0].url, date: today }); score -= Math.min(20, bad.length * 6); }
    else facts.push({ title: 'No scam-related results found in the top results', why: 'Absence of reports is not proof of safety.', source: PROV, date: today });
  }
  unknown.push({ title: 'Business registry not checked', why: 'No registry API is connected. Search your country\'s official company register (for example MCA in India) yourself.' });
  unknown.push({ title: 'Job post and offer details not cross-checked automatically', why: 'Compare the title, location and pay in the post with your offer by hand.' });

  score = Math.max(0, Math.min(100, score));
  const label = score >= 70 ? 'More evidence needed' : score >= 45 ? 'Some warning signs' : 'Several warning signs';
  res.json({ score, label, facts, warns, unknown, sources, checkedAt: new Date().toISOString() });
});

app.use((err, _req, res, _next) => res.status(400).json({ error: 'Request could not be processed.' }));
app.listen(process.env.PORT || 3000, () => console.log('OfferLens running on http://localhost:' + (process.env.PORT || 3000)));
