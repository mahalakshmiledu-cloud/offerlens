# OfferLens (local setup, Windows + VS Code)

1. Install Node.js LTS from https://nodejs.org (check: `node -v`).
2. In VS Code: File > Open Folder > `offerlens`. Open a terminal (Ctrl+`).
3. Run `npm install`.
4. Copy `.env.example` to `.env` (`copy .env.example .env`) and paste your Tavily key after `TAVILY_API_KEY=` (or a Brave key after `BRAVE_API_KEY=`).
5. Run `npm start`, then open http://localhost:3000.

Folder: `server.js` (API), `public/index.html` (frontend), `.env` (secret, never commit), `package.json`.
Frontend calls `POST /api/analyze` (letter text) and `POST /api/verify` (company). The key stays on the server.
Dependencies: express, helmet, express-rate-limit, dotenv. Browser libs via CDN: Tesseract.js (OCR), PDF.js (PDF text).
Disclaimer: scores are screening estimates, not proof that a company or offer is genuine or fraudulent.
